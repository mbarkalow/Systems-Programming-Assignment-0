#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <fcntl.h>


int main(int argc, char** argv)
{
	/*char _true[] = "true";
	//char _false[] = "false";
	
	
	char*** point = &argv;
	
	int boolean = 0;
	int count;
	for(count = 0; count < 4; count++)
	{
		if(point[0][1][count] != _true[count])
		{
			boolean = 1;
		}
	}
	
	printf("boolean = %d\n", boolean);
	//printf("Character is1: %c\n", point[0][1][0]);
	//printf("Character is2: %c\n", point[0][1][0]);
	*/
	
	
	int numExpression = 5;
	//char str[] = "Parse error in Expression %d. Unknown identifier.\n", numExpression;
	char str1[] = "Parse error in Expression";
	char str2[] = "Unknown identifier.\n";
	printf("%s %d. %s\n", str1, numExpression, str2);
	int i;
	printf("\"");
	for(i = 0; i <= 4; i++)
	{
		printf("%c", argv[1][i]);
	}
	printf("\"\n");
	return 0;
}
