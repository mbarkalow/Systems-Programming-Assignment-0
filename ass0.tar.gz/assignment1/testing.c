#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <fcntl.h>

void func(char*** ptr)
{
	printf("Function Character is: %c\n", ptr[0][1][0]);
}

int main(int argc, char** argv)
{
	char*** point = &argv;
	printf("Character is1: %c\n", point[0][1][0]);
	printf("Character is2: %c\n", argv[1][0]);
	func(&argv);
	//printf("Character is3: %c\n", point[1][0]);
	return 0;
}
