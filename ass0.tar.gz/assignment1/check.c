#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <fcntl.h>


void evaluateExpression(int begin, int end, int numExpressions, char*** argv);
int evaluateLOperator(int begin, int end, char*** argv);
void scanExpression(int begin, int end, int numExpressions, char*** argv);
int evaluateAOperand(int begin, int end, char*** argv);
int evaluateLOperand(int begin, int end, char*** argv);
int evaluateAOperator(int begin, int end, char*** argv);

int numArithmetic;
int numLogical;
int error = 0;

char AND[] = "AND";
int ANDSIZE = 3;
char OR[] = "OR";
int ORSIZE = 2;
char NOT[] = "NOT";
int NOTSIZE = 3;
char _true[] = "true";
int truesize = 4;
char _false[] = "false";
int falsesize = 5;

char **point;

char op[] = {'-', '+', '*', '/', '\0'};
char nums[] = {'1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '\0'};

void evaluateExpression(int begin, int end, int numExpressions, char*** argv)
{	
	//This function works by taking an individual expression and evaluating it. it uses argv to loop through the expression with the starting and end positions being "begin" and "end" which are parameters of the expression. The function first evaluates the operator of the expression if there is one. Then it loops through again and prints out any errors if there are any.

	// First find out the operator.
	// operator == 1 means arithmetic
	// operator == 2 means logical
	// operator == 3 means NOT
	// operator == 0 means unknown operator
	
	int realend = end - 1;
	int operator = 0;
	int i;
	int whitespace;
	int current = begin;
	if(argv[0][1][current] == ' ')
	{
		++current;
	}
	int range = current;
	int range1;
	for(i = current; i <= realend; i++)
	{
		if((argv[0][1][i] == ' ') || (i == realend))
		{
			if(i == realend)
			{
				range1 = realend;
			}
			else
			{
				whitespace = i;
				range1 = whitespace - 1;
			}
			if((evaluateAOperator(range, range1, argv)) == 1)
			{
				i = realend;
				operator = 1;
			}
			else if((evaluateLOperator(range, range1, argv)) == 1)
			{
				i = realend;
				operator = 2;
			}
			else if((evaluateLOperator(range, range1, argv)) == 2)
			{
				i = realend;
				operator = 3;
			}
			range = i + 1;
		}
	}
	// This next part of the function works by finding out what the current token is. Then, the current step of the evaluation process is checked to see what token is expected. Any errors are printed in this process.
	// step == 0 means nothing has  been evaluated yet.
	// step == 1 means the first operand has been evaluated.
	// step == 2 means the operator has been evaluated.
	// step == 3 means the last operand has been evaluated.
	int step = 0;
	current = begin;
	int ended = 0;
	int ended1 = 0;
	if(argv[0][1][current] == ' ')
	{
		++current;
	}
	range = current;
	for(i = current; i <= realend; i++)
	{
		if((ended == 1) && (step == 3))
		{
			// This if statement prints an error if an arithmetic or logical expression did not end (except for NOT).
			printf("Parse error in expression %d: expression was not ended\n", numExpressions);
			int loop;
			printf(" \"");
			for(loop = begin; loop <= realend; loop++)
			{
				printf("%c", argv[0][1][loop]);
			}
			printf("\"\n");
			error = 1;
			step = 2;
		}
		if((ended1 == 1) && (step == 2))
		{
			// This if statement checks if a NOT expression did not end.
			printf("Parse error in expression %d: expression was not ended\n", numExpressions);
			int loop;
			printf(" \"");
			for(loop = begin; loop <= realend; loop++)
			{
				printf("%c", argv[0][1][loop]);
			}
			printf("\"\n");
			error = 1;
			step = 1;
		}
		if((argv[0][1][i] == ' ') || (i == realend))
		{
			// A possible token has been identified. Find out what it is and print any needed errors.
			if(i == realend)
			{
				range1 = realend;
				
			}
			else
			{
				whitespace = i;
				range1 = whitespace - 1;
			}
			if((evaluateAOperator(range, range1, argv)) == 1)
			{
				// Token is an arithmetic operator.
				if(step == 0)
				{
					if(i == realend)
					{
						printf("Error: Parse error in expression %d: unexpected operator\n", numExpressions);
						int x3;
						printf(" \"");
						for(x3 = range; x3 <= range1; x3++)
						{
							printf("%c", argv[0][1][x3]);
						}
						printf("\"\n");
						error = 1;
						int x1;
						for(x1 = 0; x1 < 2; x1++)
						{
							printf("Error: parse error in expression %d: missing operand\n", numExpressions);
							int x;
							printf(" \"");
							for(x = begin; x <= realend; x++)
							{
								printf("%c", argv[0][1][x]);
							}
							printf("\"\n");
							error = 1;
						}
					}
					else
					{
						printf("Error: Parse error in expression %d: unexpected operator\n", numExpressions);
						int x3;
						printf(" \"");
						for(x3 = range; x3 <= range1; x3++)
						{
							printf("%c", argv[0][1][x3]);
						}
						printf("\"\n");
						error = 1;
					}
					step = 1;
				}
				else if(step == 1)
				{
					if(i == realend)
					{
						if((operator == 1) || (operator == 2))
						{
							printf("Error: parse error in expression %d: missing operand\n", numExpressions);
							int x;
							printf(" \"");
							for(x = begin; x <= realend; x++)
							{
								printf("%c", argv[0][1][x]);
							}
							printf("\"\n");
							error = 1;
							
						}
						else if(operator == 3)
						{
							printf("Error: parse error in expression %d: unexpected operator\n", numExpressions);
							int x;
							printf(" \"");
							for(x = range; x <= range1; x++)
							{
								printf("%c", argv[0][1][x]);
							}
							printf("\"\n");
							error = 1;
							if(ended1 == 0)
							{
								ended1 = 1;
								step = 2;
							}
						}
					}
					else
					{
						if(operator == 3)
						{
							printf("Error: parse error in expression %d: unexpected operator\n", numExpressions);
							int x;
							printf(" \"");
							for(x = range; x <= range1; x++)
							{
								printf("%c", argv[0][1][x]);
							}
							printf("\"\n");
							error = 1;
							if(ended1 == 0)
							{
								ended1 = 1;
								step = 2;
							}
						}
						else
						{
							step = 2;
						}
					}
				}
				else if(step == 2)
				{
					printf("Error: Parse error in expression %d: unexpected operator\n", numExpressions);
					int x;
					printf(" \"");
					for(x = range; x <= range1; x++)
					{
						printf("%c", argv[0][1][x]);
					}
					printf("\"\n");
					error = 1;
					if(ended == 0)
					{
						ended = 1;
						step = 3;
					}
				}
			}
			else if((evaluateLOperator(range, range1, argv)) == 1)
			{
				// Token is either AND or OR.
				if(step == 0)
				{
					if(i == realend)
					{
						printf("Error: Parse error in expression %d: unexpected operator\n", numExpressions);
						printf(" \"");
						int i1;
						for(i1 = range; i1 <= range1; i1++)
						{
							printf("%c", argv[0][1][i1]);
						}
						printf("\"\n");
						error = 1;
						int x1;
						for(x1 = 0; x1 < 2; x1++)
						{
							printf("Error: parse error in expression %d: missing operand\n", numExpressions);
							int x;
							printf(" \"");
							for(x = begin; x <= realend; x++)
							{
								printf("%c", argv[0][1][x]);
							}
							printf("\"\n");
							error = 1;
						}
					}
					else
					{
						printf("Error: Parse error in expression %d: unexpected operator\n", numExpressions);
						step = 1;
						printf(" \"");
						int i1;
						for(i1 = range; i1 <= range1; i1++)
						{
							printf("%c", argv[0][1][i1]);
						}
						printf("\"\n");
						error = 1;
						step = 1;
					}
				}
				else if(step == 1)
				{
					if(operator == 3)
					{
						printf("Error: parse error in expression %d: unexpected operator\n", numExpressions);
						int x;
						printf(" \"");
						for(x = range; x <= range1; x++)
						{
							printf("%c", argv[0][1][x]);
						}
						printf("\"\n");
						error = 1;
						if(ended1 == 0)
						{
							ended1 = 1;
							step = 2;
						}
					}
					else if((i == realend) && (operator == 2))
					{
						printf("Error: parse error in expression %d: missing operand\n", numExpressions);
						int x;
						printf(" \"");
						for(x = begin; x <= realend; x++)
						{
							printf("%c", argv[0][1][x]);
						}
						printf("\"\n");
						error = 1;
					}
					else if(operator == 2)
					{
						step = 2;
					}
					else if(operator == 1)
					{
						printf("Error: parse error in expression %d: unexpected operator\n", numExpressions);
						int x;
						printf(" \"");
						for(x = begin; x <= realend; x++)
						{
							printf("%c", argv[0][1][x]);
						}
						printf("\"\n");
						error = 1;
						step = 2;
					}
					
				}
				else if(step == 2)
				{
					printf("Error: Parse error in expression %d: unexpected operator\n", numExpressions);
					printf(" \"");
					int i1;
					for(i1 = range; i1 <= range1; i1++)
					{
						printf("%c", argv[0][1][i1]);
					}
					printf("\"\n");
					error = 1;
					if(ended == 0)
					{
						ended = 1;
						step = 3;
					}
				}	
			}
			else if((evaluateLOperator(range, range1, argv)) == 2)
			{
				// Token is NOT.
				if(step == 0)
				{
					if(i == realend)
					{
						printf("Error: parse error in expression %d: missing operand\n", numExpressions);
						int x;
						printf(" \"");
						for(x = begin; x <= realend; x++)
						{
							printf("%c", argv[0][1][x]);
						}
						printf("\"\n");
						error = 1;
					}
					step = 1;
				}
				else if(step == 1)
				{
					if((operator == 1) || (operator == 2))
					{	
						printf("Error: Parse error in expression %d: unexpected operator\n", numExpressions);
						printf(" \"");
						int i1;
						for(i1 = range; i1 <= range1; i1++)
						{
							printf("%c", argv[0][1][i1]);
						}
						printf("\"\n");
						error = 1;
						step = 2;
					}
					else if(operator == 3)
					{
						printf("Error: Parse error in expression %d: unexpected operator\n", numExpressions);
						printf(" \"");
						int i1;
						for(i1 = range; i1 <= range1; i1++)
						{
							printf("%c", argv[0][1][i1]);
						}
						printf("\"\n");
						error = 1;
						if(ended1 == 0)
						{
							ended1 = 1;
							step = 2;
						}
					}
				}
				
			}
			else if((evaluateAOperand(range, range1, argv)) == 1)
			{
				// Token is an arithmetic operand.
				if(step == 0)
				{
					if(i == realend)
					{
							printf("Error: parse error in expression %d: missing operator\n", numExpressions);
							int x;
							printf(" \"");
							for(x = begin; x <= realend; x++)
							{
								printf("%c", argv[0][1][x]);
							}
							printf("\"\n");
							error = 1;
						
						
					}
					else if((operator == 1) || (operator == 0)){
						step = 1;
					}
					else if(operator == 2)
					{
						printf("Error: parse error in expression %d: type mismatch\n", numExpressions);
						int x;
						printf(" \"");
						for(x = begin; x <= realend; x++)
						{
							printf("%c", argv[0][1][x]);
						}
						printf("\"\n");
						error = 1;
						step = 1;
					}
					else if(operator == 3)
					{
						printf("Error: parse error in expression %d: unexpected operand.\n", numExpressions);
						int x;
						printf(" \"");
						for(x = range; x <= range1; x++)
						{
							printf("%c", argv[0][1][x]);
						}
						printf("\"\n");
						error = 1;
						step = 1;
					}
				}
				else if(step == 1)
				{
					if(ended1 == 1)
					{
						printf("Error: parse error in expression %d: unexpected operand\n", numExpressions);
						int x;
						printf(" \"");
						for(x = range; x <= range1; x++)
						{
							printf("%c", argv[0][1][x]);
						}
						printf("\"\n");
						error = 1;
					}
					else if(operator == 3)
					{
						printf("Error: parse error in expression %d: type mismatch\n", numExpressions);
						int x;
						printf(" \"");
						for(x = begin; x <= realend; x++)
						{
							printf("%c", argv[0][1][x]);
						}
						printf("\"\n");
						error = 1;
						if(ended1 == 0)
						{
							ended1 = 1;
							step = 2;
						}
					}
					else
					{
						printf("Error: parse error in expression %d: unexpected operand\n", numExpressions);
						int x;
						printf(" \"");
						for(x = range; x <= range1; x++)
						{
							printf("%c", argv[0][1][x]);
						}
						printf("\"\n");
						error = 1;
						step = 2;
					}
				}
				else if(step == 2)
				{
					if(ended == 1)
					{
						printf("Error: parse error in expression %d: unexpected operand\n", numExpressions);
						int x;
						printf(" \"");
						for(x = range; x <= range1; x++)
						{
							printf("%c", argv[0][1][x]);
						}
						printf("\"\n");
						error = 1;
						step = 2;
					}
					else if((operator == 1) || (operator == 0))
					{
					
					}
					else if(operator == 2)
					{
						printf("Error: parse error in expression %d: type mismatch\n", numExpressions);
						int x;
						printf(" \"");
						for(x = begin; x <= realend; x++)
						{
							printf("%c", argv[0][1][x]);
						}
						printf("\"\n");
						error = 1;
					}
					if(ended == 0)
					{
						ended = 1;
						step = 3;
					}
				}
			}
			else if((evaluateLOperand(range, range1, argv)) == 1)
			{
				// Token is a logical operand.
				if(step == 0)
				{
					if(i == realend)
					{
						printf("Error: parse error in expression %d: missing operator\n", numExpressions);
						int x;
						printf(" \"");
						for(x = begin; x <= realend; x++)
						{
							printf("%c", argv[0][1][x]);
						}
						printf("\"\n");
						
						printf("Error: parse error in expression %d: missing operand\n", numExpressions);
						printf(" \"");
						for(x = begin; x <= realend; x++)
						{
							printf("%c", argv[0][1][x]);
						}
						printf("\"\n");
						error = 1;
					}
					else if((operator == 2) || (operator == 0))
					{
						step = 1;
					}
					else if(operator == 1)
					{
						printf("Error: parse error in expression %d: type mismatch\n", numExpressions);
						int x;
						printf(" \"");
						for(x = begin; x <= realend; x++)
						{
							printf("%c", argv[0][1][x]);
						}
						printf("\"\n");
						error = 1;
						step = 1;
					}
					else if(operator == 3)
					{
						printf("Error: parse error in expression %d: unexpected operand.\n", numExpressions);
						int x;
						printf(" \"");
						for(x = range; x <= range1; x++)
						{
							printf("%c", argv[0][1][x]);
						}
						printf("\"\n");
						error = 1;
						step = 1;
					}
				}
				else if(step == 1)
				{
					if(ended1 == 1)
					{
						printf("Error: parse error in expression %d: unexpected operand\n", numExpressions);
						int x;
						printf(" \"");
						for(x = range; x <= range1; x++)
						{
							printf("%c", argv[0][1][x]);
						}
						printf("\"\n");
						error = 1;
					}
					else if((operator == 1) || (operator == 2) || (operator == 0))
					{
						printf("Error: parse error in expression %d: unexpected operand\n", numExpressions);
						int x;
						printf(" \"");
						for(x = range; x <= range1; x++)
						{
							printf("%c", argv[0][1][x]);
						}
						printf("\"\n");
						error = 1;
						step = 2;
					}
					
					else if(operator == 3)
					{
						if(ended1 == 0)
						{
							ended1 = 1;
							step = 2;
						}
					}
				}
				else if(step == 2)
				{
					if(ended == 1)
					{
						printf("Error: parse error in expression %d: unexpected operand\n", numExpressions);
						int x;
						printf(" \"");
						for(x = range; x <= range1; x++)
						{
							printf("%c", argv[0][1][x]);
						}
						printf("\"\n");
						error = 1;
						step = 2;
					}
					else if(operator == 1)
					{
						printf("Error: parse error in expression %d: type mismatch\n", numExpressions);
						int x;
						printf(" \"");
						for(x = begin; x <= realend; x++)
						{
							printf("%c", argv[0][1][x]);
						}
						printf("\"\n");
						error = 1;
					}
					if(ended == 0)
					{
						ended = 1;
						step = 3;
					}
				}
			}
			else
			{
				// This is executed if the token is unknown.
				if(step == 0)
				{
					printf("Error: parse error in expression %d: unknown identifier\n", numExpressions);
					int x;
					printf(" \"");
					for(x = range; x <= range1; x++)
					{
						printf("%c", argv[0][1][x]);
					}
					printf("\"\n");
					error = 1;
					step = 0;
				}
				else if(step == 1)
				{
					if(operator == 3)
					{
						printf("Error: parse error in expression %d: unknown operand\n", numExpressions);
						int x;
						printf(" \"");
						for(x = range; x <= range1; x++)
						{
							printf("%c", argv[0][1][x]);
						}
						printf("\"\n");
						error = 1;
						if(ended1 == 0)
						{
							ended1 = 1;
							step = 2;
						}
					}
					else
					{
						printf("Error: parse error in expression %d: unknown operator\n", numExpressions);
						int x;
						printf(" \"");
						for(x = range; x <= range1; x++)
						{
							printf("%c", argv[0][1][x]);
						}
						printf("\"\n");
						error = 1;
						step = 2;
					}
				}
				else if(step == 2)
				{
					printf("Error: parse error in expression %d: unknown operand\n", numExpressions);
					int x;
					printf(" \"");
					for(x = range; x <= range1; x++)
					{
						printf("%c", argv[0][1][x]);
					}
					printf("\"\n");
					error = 1;
					if(ended == 0)
					{
						ended = 1;
						step = 3;
					}
				}
			}
			range = i + 1;
		}
	}
}

void scanExpression(int begin, int end, int numExpressions, char*** argv)
{	// The purpose of this function is to collect all of the counts. It loops through each individual expression and determines if it has a valid arithmetic or logical operator. It then increments the appropriate counters.
	int i;
	int realend = end - 1;
	int whitespace;
	if(argv[0][1][begin] == ' ')
	{
		++begin;
	}
	int range = begin;
	int range1;
	for(i = begin; i <= realend; i++)
	{
		if(argv[0][1][i] == ' ')
		{
			whitespace = i;
			range1 = whitespace - 1;
			if((evaluateAOperator(range, range1, argv)) == 1)
			{
				i = realend;
				++numArithmetic;
			}
			else if((evaluateLOperator(range, range1, argv)) == 1)
			{
				i = realend;
				++numLogical;
			}
			else if((evaluateLOperator(range, range1, argv)) == 2)
			{
				i = realend;
				++numLogical;
			}
			range = i + 1;
		}
	}
}


int evaluateAOperand(int begin, int end, char*** argv)
{
	// This function simply determines if a token is an arithmetic operand.
	// return 1 if token is an arithmetic operand.
	// return 0 if not arithmetic.
	int test = 0;
	int i;
	if(begin != end)
	{
		return test;
	}
	else
	{
		for(i = 0; i < 10; i++)
		{
			if(argv[0][1][begin] == nums[i])
			{
				test = 1;
				i = 10;
			}
		}
		return test;
	}
		
}

int evaluateLOperand(int begin, int end, char*** argv)
{
	// This function determines if a token is a logical operand.
	// return 1 if token is logical operand.
	// return 0 if token is not a logical operand.
	int i;
	int count = 0;
	int test = 1;
	int test1 = 2;
	int size = (end - begin) + 1;
	if((size != truesize) && (size != falsesize))
	{
		return 0;
	}
	for(i = begin; i <= end; i++)
	{
		if((argv[0][1][i] != _true[count]) && (test == 1) && (size == truesize))
		{
			test = 0;
		}
		if((argv[0][1][i] != _false[count]) && (test1 == 2) && (size == falsesize))
		{
			test1 = 0;
		}
		count++;
	}
	if((test == 1) || (test1 == 2))
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

int evaluateAOperator(int begin, int end, char*** argv)
{
	// This function determines if a token is an arithmetic operator.
	// return 1 if arithmetic operator.
	// return 0 if not an arithmetic operator.
	int i;
	int test = 0;
	if(begin != end)
	{
		return test;
	}
	else
	{
		for(i = 0; i < 4; i++)
		{
			if(argv[0][1][begin] == op[i])
			{
				test = 1;
			}
		}
		return test;
	}
}

int evaluateLOperator(int begin, int end, char*** argv)
{
	// This function determines if a token is a logical operator.
	// return 1 if operator is AND / OR
	// return 2 if operator is NOT
	// else, return 0.
	int i;
	int count = 0;
	int test = 1;
	int test1 = 2;
	int test2 = 3;
	int size = (end - begin) + 1;
	if((size != ANDSIZE) && (size != ORSIZE) && (size != NOTSIZE))
	{
		return 0;
	}
	for(i = begin; i <= end; i++)
	{
		if(count < 3)
		{
			if((argv[0][1][i] != AND[count]) && (test == 1))
			{
				test = 0;
			}
			if((argv[0][1][i] != NOT[count]) && (test2 == 3))
			{
				test2 = 0;
			}
		}
		else
		{
			test = 0;
			test2 = 0;
		}
		if(count < 2)
		{
			if((argv[0][1][i] != OR[count]) && (test1 == 2))
			{
				test1 = 0;
			}
		}
		else
		{
			test1 = 0;
		}
		count++;
	}
	if((test == 1) || (test1 == 2))
	{
		return 1;
	}
	if(test2 == 3)
	{
		return 2;
	}
	else
	{
		return 0;
	}
}

int main(int argc, char** argv)
{
	int numExpressions = 0;
	numArithmetic = 0;
	numLogical = 0;
	
	if(argc != 2)
	{
		//print error if there are not 2 arguments.
		printf("Error. There should only be 1 argument.\n");
	}
	else
	{
		//int i = 0;
		int start = 0;
		int position = 0;
		if(argv[1][position] == '\0')
		{
			//print error if the input is a blank expression.
			printf("Scan error in expression %d: incomplete expression\n", numExpressions);
			printf(" \"");
			printf("\"\n");
			error = 1;
		}
		while(argv[1][position] != '\0')
		{
		//This while loop loops through the argument to produce the number of expressions, and how many logical and arithmetic expressions there are.
			if(argv[1][position] == ';')
			{
				++numExpressions;
				scanExpression(start, position, numExpressions, &argv);	
				start = position + 1;
			}
			++position;
		}
		//These few lines account for the fact that the last expression will not end with a semicolon.
		++numExpressions;
		scanExpression(start, position, numExpressions, &argv);
		printf("Found %d expressions. %d logical and %d arithmetic.\n", numExpressions, numLogical, numArithmetic);
		
		start = 0;
		position = 0;
		numExpressions = 0;
		while(argv[1][position] != '\0')
		{
		//This while loop goes through the argument again to print the errors.
			if(argv[1][position] == ';')
			{
				//++numExpressions;
				//See the function "evaluateExpression" to look at what this does.
				evaluateExpression(start, position, numExpressions, &argv);
				++numExpressions;
				if(argv[1][position + 1] == '\0')
				{
				//This if statement catches if there is an expression that ends with a semicolon but does not have an expression following it.
					printf("Scan error in expression %d: incomplete expression\n", (numExpressions - 1));
					printf(" \"");
					printf("\"\n");
					error = 1;
				}
				start = position + 1;
				
			}
			++position;
		}
		evaluateExpression(start, position, numExpressions, &argv);
		
		if(error == 0)
		{
			printf("OK.\n");
		}
	}
	return 0;
	
}
